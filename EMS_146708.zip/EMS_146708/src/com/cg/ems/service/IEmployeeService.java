package com.cg.ems.service;

import java.util.List;

import com.cg.ems.bean.EmployeeBean;
import com.cg.ems.exception.EmployeeException;

public interface IEmployeeService {
	public int addEmployee(EmployeeBean bean) throws EmployeeException;
	public EmployeeBean findEmployeeById(int employeeId) throws EmployeeException;
	public EmployeeBean deleteEmployeebyId(int employeeId) throws EmployeeException;
	public List<EmployeeBean> viewAllEmployees() throws EmployeeException;
}
