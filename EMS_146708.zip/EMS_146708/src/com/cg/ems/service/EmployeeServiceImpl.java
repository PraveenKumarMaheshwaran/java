package com.cg.ems.service;

import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import com.cg.ems.bean.EmployeeBean;
import com.cg.ems.dao.EmployeeDaoImpl;
import com.cg.ems.dao.IEmployeeDao;
import com.cg.ems.exception.EmployeeException;

public class EmployeeServiceImpl implements  IEmployeeService{
	private IEmployeeDao employeeDao=new EmployeeDaoImpl();
	@Override
	public int addEmployee(EmployeeBean bean) throws EmployeeException {
		// TODO Auto-generated method stub
		int id=0;
		id=employeeDao.addEmployee(bean);
		return id;
	}

	@Override
	public EmployeeBean findEmployeeById(int employeeId)
			throws EmployeeException {
		// TODO Auto-generated method stub
		EmployeeBean bean=null;
		bean=employeeDao.findEmployeeById(employeeId);
		return bean;
	}
	public void validateEmployee(EmployeeBean bean) throws EmployeeException
	{
		List<String> validationErrors = new ArrayList<String>();

		//Validating donor name
		if(!(isValidName(bean.getEmployeeName()))) {
			validationErrors.add("\n Employee Name Should Be In Alphabets and minimum 3 characters long ! \n");
		}
		/*
		//Validating address
		if(!(isValidAddress(bean.getAddress()))){
			validationErrors.add("\n Address Should Be Greater Than 5 Characters \n");
		}
		//Validating Phone Number
		if(!(isValidPhoneNumber(bean.getPhoneNumber()))){
			validationErrors.add("\n Phone Number Should be in 10 digit \n");
		}
		//Validating Donation Amount
		if(!(isValidAmount(bean.getDonationAmount()))){
			validationErrors.add("\n Amount Should be a positive Number \n" );
		}*/
		
		if(!validationErrors.isEmpty())
			throw new EmployeeException(validationErrors +"");
	}

	public boolean isValidName(String donorName){
		Pattern namePattern=Pattern.compile("^[A-Za-z]{3,}$");
		Matcher nameMatcher=namePattern.matcher(donorName);
		return nameMatcher.matches();
	}
	public boolean isValidAddress(String address){
		return (address.length() > 6);
	}
	
	public boolean isValidPhoneNumber(String phoneNumber){
		Pattern phonePattern=Pattern.compile("^[1-9]{1}[0-9]{9}$");
		Matcher phoneMatcher=phonePattern.matcher(phoneNumber);
		return phoneMatcher.matches();
		
	}
	public boolean isValidAmount(double amount){
		return (amount>0);
	}
	public boolean validateDonorId(String donorId) {
		
		Pattern idPattern = Pattern.compile("[0-9]{1,4}");
		Matcher idMatcher = idPattern.matcher(donorId);
		
		if(idMatcher.matches())
			return true;
		else
			return false;		
	}

	@Override
	public EmployeeBean deleteEmployeebyId(int employeeId)
			throws EmployeeException {
		// TODO Auto-generated method stub
		EmployeeBean bean=null;
		bean=employeeDao.deleteEmployeebyId(employeeId);
		return bean;
	}
	
}
