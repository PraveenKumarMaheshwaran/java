package com.cg.ems.pl;

import java.util.List;
import java.util.Scanner;

import com.cg.ems.bean.EmployeeBean;
import com.cg.ems.exception.EmployeeException;
import com.cg.ems.service.EmployeeServiceImpl;

public class EmsApp {
	public static void main(String[] args){
		Scanner sc=new Scanner(System.in);
		EmployeeServiceImpl service=new EmployeeServiceImpl();
		EmployeeBean bean=new EmployeeBean();
		while(true)
		{
			System.out.println("1,Add Employee");
			System.out.println("2,Find By Id");
			System.out.println("3,Delete");
			System.out.println("4,View");
			System.out.println("5,Exit");
			System.out.println("Enter your Choice");
			int choice =sc.nextInt();
			switch(choice)
			{
			case 1: sc.nextLine();
					System.out.println("Enter name");
					String name=sc.nextLine();
					System.out.println("Enter the salary");
					int salary=sc.nextInt();
					bean.setEmployeeName(name);
					bean.setEmployeeSalary(salary);
					try{
					service.validateEmployee(bean);
					int id=service.addEmployee(bean);
					System.out.println("Employee Added ID="+id);
					}
					catch(EmployeeException e)
					{
						System.out.println(e);
					}
					break;
			case 2:		System.out.println("enter Employee Id");
						int id=sc.nextInt();
						try{
						bean=service.findEmployeeById(id);
						System.out.println("EmpId="+bean.getEmployeeId());
						System.out.println("Name="+bean.getEmployeeName());
						System.out.println("Dob="+bean.getEmployeeDOB());
						System.out.println("Salary="+bean.getEmployeeSalary());
						}
						catch(EmployeeException e)
						{
							System.out.println("Id Not found");
						}
						break;
			case 3:		System.out.println("Enter the Id to be deleted");
						int id1=sc.nextInt();
						try{
							bean=service.deleteEmployeebyId(id1);
							System.out.println("Id Deleted");
						}
						catch(EmployeeException e)
						{
							System.out.println("Id not Found");
						}
						break;
			case 4:try{
				 List<EmployeeBean> list=service.viewAllEmployees();
					for(EmployeeBean emp:list)
					{
						System.out.println("Id="+emp.getEmployeeId());
						System.out.println("Name="+emp.getEmployeeName());
						System.out.println("Dob="+emp.getEmployeeDOB());
						System.out.println("Salary="+emp.getEmployeeSalary());
					}
			}
			catch(EmployeeException e)
			{
				System.out.println("No data");
			}
			break;
			case 5:		System.out.println("po da ****");
						System.exit(0);
						
						
		}
	}

}}
