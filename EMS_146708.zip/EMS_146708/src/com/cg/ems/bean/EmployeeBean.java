package com.cg.ems.bean;

import java.util.Date;

public class EmployeeBean {
	private int employeeId;
	private String employeeName;
	private Date employeeDOB;
	private int employeeSalary;
	@Override
	public String toString() {
		return "EmployeeBean [employeeId=" + employeeId + ", employeeName="
				+ employeeName + ", employeeDOB=" + employeeDOB
				+ ", employeeSalary=" + employeeSalary + "]";
	}
	public int getEmployeeId() {
		return employeeId;
	}
	public void setEmployeeId(int employeeId) {
		this.employeeId = employeeId;
	}
	public String getEmployeeName() {
		return employeeName;
	}
	public void setEmployeeName(String employeeName) {
		this.employeeName = employeeName;
	}
	public Date getEmployeeDOB() {
		return employeeDOB;
	}
	public void setEmployeeDOB(Date employeeDOB) {
		this.employeeDOB = employeeDOB;
	}
	public int getEmployeeSalary() {
		return employeeSalary;
	}
	public void setEmployeeSalary(int employeeSalary) {
		this.employeeSalary = employeeSalary;
	}

}
