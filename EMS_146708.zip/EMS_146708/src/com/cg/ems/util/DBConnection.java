package com.cg.ems.util;

import java.io.*;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Properties;

import com.cg.ems.exception.EmployeeException;

public class DBConnection {

	public static Connection getConnection() throws EmployeeException
	{
		Connection con=null;
		try
		{
			FileReader fr=new FileReader("resources/jdbc.properties");
			Properties prop=new Properties();
			prop.load(fr);
			String url=prop.getProperty("dburl");
			String user=prop.getProperty("name");
			String pass=prop.getProperty("pass");
			con = DriverManager.getConnection(url,user,pass);
		}
		catch(FileNotFoundException e)
		{
			con=null;
			throw new EmployeeException("JDBC.properties file not found");
		}
		catch(IOException e)
		{
			con=null;
			throw new EmployeeException("Unable to read jdbc.properties file");
		}
		catch(SQLException e)
		{
			con=null;
			throw new EmployeeException("Connection error"+e.getMessage());
		}
		return con;
	}
}
