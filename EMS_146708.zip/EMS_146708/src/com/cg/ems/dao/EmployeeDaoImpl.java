package com.cg.ems.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import com.cg.ems.bean.EmployeeBean;
import com.cg.ems.exception.EmployeeException;
import com.cg.ems.util.DBConnection;

public class EmployeeDaoImpl  implements IEmployeeDao{
	private Logger logger=Logger.getLogger(EmployeeDaoImpl.class);
	public EmployeeDaoImpl()
	{
		PropertyConfigurator.configure("resources/log4j.properties");
	}

	@Override
	public int addEmployee(EmployeeBean bean) throws EmployeeException {
		int empid=-1;
		try{
		Connection con= DBConnection.getConnection();
		PreparedStatement pst=con.prepareStatement(QueryMapper.INSERT_QUERY);
		pst.setString(1, bean.getEmployeeName());
		pst.setInt(2, bean.getEmployeeSalary());
		int result=pst.executeUpdate();
		if(result==0)
		{
			logger.error("Unable to insert record");
			throw new EmployeeException("Insert fail");
		}
		pst=con.prepareStatement(QueryMapper.SEQENCE_QUERY);
		ResultSet rst=pst.executeQuery();
		if(rst.next())
		{
			empid=rst.getInt(1);
		}
		else{
			logger.error("Unable to fetch sequence");
			throw new EmployeeException("Unable to fetch sequence");
		}
		con.close();
		}
		catch(SQLException e)
		{
			empid=-1;
			logger.error(e.getMessage());
			throw new EmployeeException(e.getMessage());
		}
		logger.info("Add Employee Completed");
		return empid;
	}

	@Override
	public EmployeeBean findEmployeeById(int employeeId)
			throws EmployeeException {
		EmployeeBean bean=new EmployeeBean();
		try{
		Connection con=DBConnection.getConnection();
		PreparedStatement pst=con.prepareStatement(QueryMapper.SELECT_QUERY);
		pst.setInt(1, employeeId);
		ResultSet rst=pst.executeQuery();
		if(rst.next())
		{
			bean.setEmployeeId(rst.getInt(1));
			bean.setEmployeeName(rst.getString(2));
			bean.setEmployeeDOB(rst.getDate(3));
			bean.setEmployeeSalary(rst.getInt(4));
			
		}
		else{
			throw new EmployeeException("Id not Found");
		}
		con.close();
		}
		catch(SQLException e)
		{
			logger.error(e.getMessage());
			throw new EmployeeException(e.getMessage());
		}
		return bean;
	}

	@Override
	public EmployeeBean deleteEmployeebyId(int employeeId)
			throws EmployeeException {
		// TODO Auto-generated method stub
		EmployeeBean bean=new EmployeeBean();
		try{
		Connection con=DBConnection.getConnection();
		PreparedStatement pst=con.prepareStatement(QueryMapper.DELETE_QUERY);
		pst.setInt(1, employeeId);
		ResultSet rst=pst.executeQuery();
		if(rst.next())
		{
			bean.getEmployeeId();
			bean.getEmployeeName();
			bean.getEmployeeDOB();
			bean.getEmployeeSalary();
		}
		else{
			System.out.println("Id not found");
		}
		
		con.close();
	
		}
		catch(SQLException e)
		{
			logger.error(e.getMessage());
			throw new EmployeeException(e.getMessage());
		}
		
		
		return bean;
	}

	@Override
	public List<EmployeeBean> viewAllEmployees() throws EmployeeException {
		// TODO Auto-generated method stub
		List<EmployeeBean> list=new ArrayList<EmployeeBean>();
		try{
		Connection con=DBConnection.getConnection();
		PreparedStatement pst=con.prepareStatement(QueryMapper.VIEW_QUERY);
		ResultSet rst=pst.executeQuery();
		while(rst.next())
		{
			EmployeeBean bean=new EmployeeBean();
			bean.setEmployeeId(rst.getInt("empId"));
			bean.setEmployeeName(rst.getString("empName"));
			bean.setEmployeeDOB(rst.getDate("empdob"));
			bean.setEmployeeSalary(rst.getInt("empSal"));
			list.add(bean);
		}
		con.close();
	}
		catch(Exception e)
		{
			throw new EmployeeException(e.getMessage());
		}
		
		
		return list;
	}
	

}
