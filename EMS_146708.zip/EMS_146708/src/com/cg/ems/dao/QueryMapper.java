package com.cg.ems.dao;

public interface QueryMapper {
	public static String SELECT_QUERY="select empid,empname,empdob,empsal from employee_tbl where empid=?";
	public static String INSERT_QUERY="insert into employee_tbl values(emp_seq.nextval,?,sysdate,?)";
	public static String DELETE_QUERY="delete from employee_tbl where empid=?";
	public static String SEQENCE_QUERY="select emp_seq.currval from dual";

}
