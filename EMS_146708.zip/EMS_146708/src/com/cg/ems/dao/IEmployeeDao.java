package com.cg.ems.dao;

import com.cg.ems.bean.EmployeeBean;
import com.cg.ems.exception.EmployeeException;

public interface IEmployeeDao {
	public int addEmployee(EmployeeBean bean) throws EmployeeException;
	public EmployeeBean findEmployeeById(int employeeId) throws EmployeeException;
	public EmployeeBean deleteEmployeebyId(int employeeId) throws EmployeeException;

}
