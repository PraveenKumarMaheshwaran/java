package com.cg.ems.test;

import static org.junit.Assert.*;

import org.junit.BeforeClass;
import org.junit.Test;
import org.junit.Test;

import com.cg.ems.bean.EmployeeBean;
import com.cg.ems.dao.EmployeeDaoImpl;
import com.cg.ems.dao.IEmployeeDao;
import com.cg.ems.exception.EmployeeException;

public class EmployeeDaoTest {
		static IEmployeeDao employeeDao;
		static EmployeeBean bean;
		@BeforeClass
		public static void init()
		{
			employeeDao=new EmployeeDaoImpl();
			bean=new EmployeeBean();
		}
		@Test
		public void testAddEmployee() throws EmployeeException
		{
			bean.setEmployeeName("John");;
			bean.setEmployeeSalary(12000);
			int id=employeeDao.addEmployee(bean);
			assertTrue(id>0);
		}
		@Test
		public void testFindEmployeeById() throws EmployeeException
		{
			bean.setEmployeeName("John");;
			bean.setEmployeeSalary(12000);
			int id=employeeDao.addEmployee(bean);
		bean=employeeDao.findEmployeeById(id);
			assertEquals(id,bean.getEmployeeId());
		}
		
		
}
